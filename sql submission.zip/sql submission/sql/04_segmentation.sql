-- ============================================================================
-- D2C CUSTOMER VALUE & RETENTION STRATEGY
-- PostgreSQL Segmentation Layer
--
-- Input : customers_segmented.csv  (30 columns, exported by Phase 3 notebook)
-- Output: 5 key-question queries, 4 dashboard views, 2 sizing queries
--
-- SECTION 1  Schema and load          <-- DESTRUCTIVE, run once only
-- SECTION 2  Analytical constants
-- SECTION 3  The five key questions
-- SECTION 4  Dashboard views
-- SECTION 5  Sunset sizing (observed purchase)
-- SECTION 6  Sunset sizing (annualised)
--
-- Companion file: 05_dashboard_views.sql adds the gender-artefact and
-- male-scoped views built after significance testing.
-- ============================================================================


-- ============================================================================
-- SECTION 1 — SCHEMA
-- ----------------------------------------------------------------------------
-- WARNING: begins with DROP TABLE ... CASCADE. Running this after the data is
-- loaded deletes the table AND every view built on it. Run once, then never
-- again.
--
-- Columns are declared in the exact order the CSV writes them, with snake_case
-- names. COPY ... WITH HEADER matches by POSITION, not by name, so the header
-- row is skipped and 'Purchase Amount (USD)' lands in purchase_amount without
-- needing quoted identifiers anywhere downstream.
-- ============================================================================

DROP TABLE IF EXISTS customers CASCADE;

CREATE TABLE customers (
    customer_id         INTEGER PRIMARY KEY,
    age                 INTEGER,
    gender              TEXT,
    category            TEXT,
    purchase_amount     NUMERIC(10,2),
    location            TEXT,
    season              TEXT,
    review_rating       NUMERIC(3,1),
    payment_method      TEXT,
    shipping_type       TEXT,
    previous_purchases  INTEGER,
    freq_clean          TEXT,
    annual_rate         INTEGER,
    implied_tenure_yrs  NUMERIC(10,4),
    tenure_rank         NUMERIC(6,4),
    tenure_band         TEXT,
    est_lifetime_rev    NUMERIC(12,2),
    value_tier          TEXT,
    is_discounted       BOOLEAN,
    full_price_buyer    BOOLEAN,
    shipping_premium    BOOLEAN,
    satisfaction_band   TEXT,
    loyal_a             BOOLEAN,
    pt_full_price       BOOLEAN,
    pt_frequent         BOOLEAN,
    pt_satisfied        BOOLEAN,
    pt_pays_speed       BOOLEAN,
    score_b             INTEGER,
    loyal_b             BOOLEAN,
    segment             TEXT
);

CREATE INDEX idx_customers_segment    ON customers (segment);
CREATE INDEX idx_customers_location   ON customers (location);
CREATE INDEX idx_customers_value_tier ON customers (value_tier);

-- Load from psql (client-side path, no server file permissions needed):
--   \copy customers FROM 'customers_segmented.csv' WITH (FORMAT csv, HEADER true)
--
-- Verification: should return 30 rows, customer_id first, segment last.
-- SELECT column_name, data_type
-- FROM information_schema.columns
-- WHERE table_name = 'customers'
-- ORDER BY ordinal_position;


-- ============================================================================
-- SECTION 2 — ANALYTICAL CONSTANTS
-- ----------------------------------------------------------------------------
-- Every threshold used anywhere in this file lives here, so a reviewer can see
-- and challenge all of them in one place. Hard-coding 60 in eight queries is
-- how two deliverables quietly end up disagreeing with each other.
-- ============================================================================

DROP VIEW IF EXISTS v_params CASCADE;

CREATE VIEW v_params AS
SELECT
    60    AS min_state_n,        -- sample-size floor for any geographic ranking
    0.20  AS assumed_discount_depth,
    0.58  AS assumed_gross_margin;


-- ============================================================================
-- SECTION 3 — THE FIVE KEY QUESTIONS
-- ============================================================================


-- ----------------------------------------------------------------------------
-- Q1. Who are the genuinely loyal customers vs. those who only buy on discount?
--
-- Reads the four-quadrant segmentation. Interpretation note that belongs in the
-- report: the discount_rate column is PARTLY DEFINITIONAL, because full-price
-- purchase is one of the four points in the loyalty score. Segment sizes and
-- revenue shares are not definitional and carry the argument.
-- ----------------------------------------------------------------------------

SELECT
    segment,
    COUNT(*)                                              AS customers,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1)    AS pct_of_base,
    ROUND(AVG(est_lifetime_rev), 0)                       AS avg_est_rev,
    ROUND(100.0 * SUM(est_lifetime_rev)
                / SUM(SUM(est_lifetime_rev)) OVER (), 1)  AS pct_of_revenue,
    ROUND(100.0 * COUNT(*) FILTER (WHERE is_discounted)
                / COUNT(*), 1)                            AS discount_rate,
    ROUND(AVG(review_rating), 2)                          AS avg_rating,
    ROUND(AVG(annual_rate), 1)                            AS avg_purchases_yr
FROM customers
GROUP BY segment
ORDER BY segment;


-- ----------------------------------------------------------------------------
-- Q2. What behavioural patterns today predict high customer value over time?
--
-- Tests each behavioural flag against value tier membership. value_tier is
-- built from (previous_purchases + 1) * purchase_amount and never touches
-- annual_rate, discount status, review rating or shipping choice — so all four
-- comparisons below are independent of the value calculation.
--
-- lift = how much more common the behaviour is in the top tier vs the base.
-- Lift near 1.00 means no relationship at all.
-- ----------------------------------------------------------------------------

WITH base AS (
    SELECT
        AVG(CASE WHEN pt_full_price     THEN 1.0 ELSE 0 END) AS b_full_price,
        AVG(CASE WHEN pt_frequent       THEN 1.0 ELSE 0 END) AS b_frequent,
        AVG(CASE WHEN pt_satisfied      THEN 1.0 ELSE 0 END) AS b_satisfied,
        AVG(CASE WHEN pt_pays_speed     THEN 1.0 ELSE 0 END) AS b_pays_speed
    FROM customers
),
top_tier AS (
    SELECT
        AVG(CASE WHEN pt_full_price     THEN 1.0 ELSE 0 END) AS t_full_price,
        AVG(CASE WHEN pt_frequent       THEN 1.0 ELSE 0 END) AS t_frequent,
        AVG(CASE WHEN pt_satisfied      THEN 1.0 ELSE 0 END) AS t_satisfied,
        AVG(CASE WHEN pt_pays_speed     THEN 1.0 ELSE 0 END) AS t_pays_speed
    FROM customers
    WHERE value_tier = 'T1 Highest'
)
SELECT 'Buys at full price'      AS behaviour,
       ROUND(100 * b_full_price, 1) AS pct_base,
       ROUND(100 * t_full_price, 1) AS pct_top_tier,
       ROUND(t_full_price / NULLIF(b_full_price, 0), 2) AS lift,
       'independent of value calc' AS note
FROM base, top_tier
UNION ALL
SELECT 'Buys monthly or more',
       ROUND(100 * b_frequent, 1), ROUND(100 * t_frequent, 1),
       ROUND(t_frequent / NULLIF(b_frequent, 0), 2),
       'independent of value calc'
FROM base, top_tier
UNION ALL
SELECT 'Top-tercile rating',
       ROUND(100 * b_satisfied, 1), ROUND(100 * t_satisfied, 1),
       ROUND(t_satisfied / NULLIF(b_satisfied, 0), 2),
       'independent of value calc'
FROM base, top_tier
UNION ALL
SELECT 'Pays for faster shipping',
       ROUND(100 * b_pays_speed, 1), ROUND(100 * t_pays_speed, 1),
       ROUND(t_pays_speed / NULLIF(b_pays_speed, 0), 2),
       'independent of value calc'
FROM base, top_tier;


-- ----------------------------------------------------------------------------
-- Q3. Which geographies and demographics are commercially underlevered?
--
-- "Underlevered" is defined explicitly, not asserted: a state where average
-- spend is at or above the national median AND promo dependency is below it.
--
-- IMPORTANT — READ BEFORE CITING THIS OUTPUT:
-- The quadrants split at the median on both axes, so roughly 25% of states
-- land in each quadrant whether or not any real relationship exists. The
-- classification is descriptive, NOT evidence of opportunity.
--
-- Permutation testing (2,000 shuffles) found:
--   * state revenue variation      p = 0.12  (indistinguishable from chance)
--   * extreme states are small     r = -0.35 (noise signature)
--   * male-only promo variation    p = 0.93  (NARROWER than chance)
--   * state male share vs promo    r = 0.71  (the pattern is a gender artefact)
--
-- Conclusion: no state-level growth recommendation is made. See the companion
-- view vw_geo_gender_artefact in 05_dashboard_views.sql.
-- ----------------------------------------------------------------------------

WITH state_stats AS (
    SELECT
        c.location,
        COUNT(*)                                                   AS customers,
        AVG(c.est_lifetime_rev)                                    AS avg_rev,
        AVG(CASE WHEN c.is_discounted THEN 1.0 ELSE 0 END)         AS promo_rate,
        AVG(c.review_rating)                                       AS avg_rating
    FROM customers c
    GROUP BY c.location
    HAVING COUNT(*) >= (SELECT min_state_n FROM v_params)   -- minimum-n filter
),
ranked AS (
    SELECT
        location, customers, avg_rev, promo_rate, avg_rating,
        -- PERCENT_RANK() returns double precision, and Postgres has no
        -- round(double precision, integer). Cast to numeric explicitly.
        PERCENT_RANK() OVER (ORDER BY avg_rev)::numeric    AS rev_pctile,
        PERCENT_RANK() OVER (ORDER BY promo_rate)::numeric AS promo_pctile
    FROM state_stats
)
SELECT
    location,
    customers,
    ROUND(avg_rev, 0)             AS avg_est_rev,
    ROUND(100 * promo_rate, 1)    AS promo_rate_pct,
    ROUND(avg_rating, 2)          AS avg_rating,
    ROUND(rev_pctile, 2)          AS rev_pctile,
    ROUND(promo_pctile, 2)        AS promo_pctile,
    CASE
        WHEN rev_pctile >= 0.5 AND promo_pctile <  0.5 THEN 'A. Organic strength - underlevered'
        WHEN rev_pctile >= 0.5 AND promo_pctile >= 0.5 THEN 'B. Discount-driven volume'
        WHEN rev_pctile <  0.5 AND promo_pctile <  0.5 THEN 'C. Low engagement'
        ELSE                                                'D. Expensive and weak'
    END AS opportunity_quadrant
FROM ranked
ORDER BY rev_pctile DESC, promo_pctile ASC;


-- ----------------------------------------------------------------------------
-- Q4. How should the brand restructure promotions to protect margin
--     without losing volume?
--
-- The core evidence of the whole project. Value tier is built from purchase
-- count and amount only, so discount status played no part in it. This table
-- is therefore NOT circular and it is the strongest claim available.
--
-- Observed result: discount rate 40.5% to 44.9% across tiers, non-monotonic.
-- Scoped to male customers (the only ones ever discounted): 61.6% for the
-- lowest-value quintile against 61.7% for the highest.
--
-- A flat discount_rate column means promotional spend has no relationship to
-- customer value: the brand discounts its best customers at the same rate as
-- its worst.
--
-- Note: margin_at_stake rises across tiers partly by construction, since
-- higher tiers hold higher purchase amounts. Read discount_rate_pct, not
-- margin_at_stake, as the finding.
-- ----------------------------------------------------------------------------

WITH tier_stats AS (
    SELECT
        value_tier,
        COUNT(*)                                            AS customers,
        AVG(CASE WHEN is_discounted THEN 1.0 ELSE 0 END)    AS discount_rate,
        SUM(purchase_amount) FILTER (WHERE is_discounted)   AS discounted_revenue,
        AVG(est_lifetime_rev)                               AS avg_est_rev
    FROM customers
    GROUP BY value_tier
)
SELECT
    t.value_tier,
    t.customers,
    ROUND(100 * t.discount_rate, 1)      AS discount_rate_pct,
    ROUND(t.avg_est_rev, 0)              AS avg_est_rev,
    ROUND(t.discounted_revenue, 0)       AS discounted_revenue,
    ROUND(t.discounted_revenue * p.assumed_discount_depth
          / (1 - p.assumed_discount_depth), 0) AS margin_at_stake,
    ROUND(100 * (t.discount_rate
          - (SELECT AVG(CASE WHEN is_discounted THEN 1.0 ELSE 0 END)
             FROM customers)), 1)        AS pts_vs_base_rate
FROM tier_stats t
CROSS JOIN v_params p
ORDER BY t.value_tier DESC;


-- ----------------------------------------------------------------------------
-- Q5. What does the ideal customer profile look like?
--
-- Reports LIFT, not modal values. A modal value is only a targeting
-- instruction if the attribute is over-represented relative to the base rate:
-- "45% of loyalists buy Clothing" says nothing when Clothing is 44.5% of every
-- customer. Lift above ~1.2 is a signal; lift near 1.00 is the base rate
-- wearing a hat.
--
-- The caveat column is essential. Purchase cadence and shipping choice are
-- inputs to the loyalty score, so their high lift is definitional. Gender is
-- the most definitional of all: no female customer in the dataset was ever
-- discounted, so all 1,248 women are automatically awarded the full-price
-- point. Female over-representation among loyalists is mechanical, not
-- behavioural.
--
-- Observed result: with the definitional rows excluded, NOTHING demographic
-- clears 1.2. The ideal customer profile is therefore behavioural, not
-- demographic.
-- ----------------------------------------------------------------------------

WITH attrs AS (
    SELECT segment, 'Age band' AS attribute,
           CASE WHEN age < 25 THEN 'Under 25' WHEN age < 35 THEN '25-34'
                WHEN age < 45 THEN '35-44'   WHEN age < 55 THEN '45-54'
                ELSE '55+' END AS value
    FROM customers
    UNION ALL SELECT segment, 'Category',         category       FROM customers
    UNION ALL SELECT segment, 'Season',           season         FROM customers
    UNION ALL SELECT segment, 'Payment method',   payment_method FROM customers
    UNION ALL SELECT segment, 'Shipping choice',  shipping_type  FROM customers
    UNION ALL SELECT segment, 'Purchase cadence', freq_clean     FROM customers
    UNION ALL SELECT segment, 'Gender',           gender         FROM customers
),
agg AS (
    SELECT attribute, value,
           COUNT(*) FILTER (WHERE segment = '1. True Loyalist') AS n_loyal,
           COUNT(*)                                            AS n_all
    FROM attrs
    GROUP BY attribute, value
),
tot AS (
    SELECT (SELECT COUNT(*) FROM customers WHERE segment = '1. True Loyalist')::numeric AS loyal_total,
           (SELECT COUNT(*) FROM customers)::numeric                                    AS all_total
)
SELECT
    a.attribute,
    a.value,
    a.n_loyal,
    ROUND(100 * a.n_loyal / t.loyal_total, 1)                        AS pct_loyalists,
    ROUND(100 * a.n_all   / t.all_total,   1)                        AS pct_base,
    ROUND((a.n_loyal / t.loyal_total)
          / NULLIF(a.n_all / t.all_total, 0), 2)                     AS lift,
    CASE
        WHEN a.attribute IN ('Shipping choice', 'Purchase cadence')
             THEN 'partly definitional'
        WHEN a.attribute = 'Gender'
             THEN 'DEFINITIONAL: no female customer was discounted'
        ELSE 'independent'
    END                                                              AS caveat
FROM agg a
CROSS JOIN tot t
WHERE a.n_loyal >= 15          -- suppress cells too small to read
ORDER BY lift DESC;


-- ============================================================================
-- SECTION 4 — DASHBOARD VIEWS
-- ============================================================================


-- Panel 1: Customer pyramid — how value is distributed across the base.
-- The point of this panel is revenue SHARE, not customer counts. Quintiles
-- always hold 20% of customers each; whether the top holds 20% or 43% of
-- revenue is the actual finding.

DROP VIEW IF EXISTS vw_customer_pyramid CASCADE;

CREATE VIEW vw_customer_pyramid AS
SELECT
    value_tier,
    CASE value_tier
        WHEN 'T1 Highest' THEN 1 WHEN 'T2' THEN 2 WHEN 'T3' THEN 3
        WHEN 'T4' THEN 4 ELSE 5 END                             AS tier_rank,
    COUNT(*)                                                    AS customers,
    ROUND(AVG(est_lifetime_rev), 0)                             AS avg_est_rev,
    ROUND(SUM(est_lifetime_rev), 0)                             AS total_est_rev,
    ROUND(100.0 * SUM(est_lifetime_rev)
                / SUM(SUM(est_lifetime_rev)) OVER (), 1)        AS pct_of_revenue,
    ROUND(100.0 * COUNT(*) FILTER (WHERE is_discounted)
                / COUNT(*), 1)                                  AS discount_rate
FROM customers
GROUP BY value_tier;


-- Panel 2: Promo dependency vs. retention proxy, by segment.
--
-- CAUTION, and this belongs on the dashboard itself, not buried in the report:
-- there is no churn label, so retention must be proxied. The obvious proxy —
-- share of the segment in the Established/Long-standing tenure bands — returns
-- exactly 100% for both A-loyal segments, because loyal_A REQUIRES those bands.
-- That is circular and it looks like a spectacular result, which is what makes
-- it dangerous.
--
-- Instead we use average tenure percentile, which still leans on the same
-- variable but varies continuously and can be reported with its constraint
-- stated. avg_prev_purchases is shown alongside so a reader can see the raw
-- input rather than only the derived index.

DROP VIEW IF EXISTS vw_promo_vs_retention CASCADE;

CREATE VIEW vw_promo_vs_retention AS
SELECT
    segment,
    COUNT(*)                                                     AS customers,
    ROUND(100.0 * COUNT(*) FILTER (WHERE is_discounted)
                / COUNT(*), 1)                                   AS promo_dependency,
    ROUND(100 * AVG(tenure_rank), 1)                             AS tenure_index,
    ROUND(AVG(previous_purchases), 1)                            AS avg_prev_purchases,
    ROUND(AVG(annual_rate), 1)                                   AS avg_purchases_yr,
    ROUND(AVG(est_lifetime_rev), 0)                              AS avg_est_rev,
    ROUND(100.0 * SUM(est_lifetime_rev)
                / SUM(SUM(est_lifetime_rev)) OVER (), 1)         AS pct_of_revenue
FROM customers
GROUP BY segment;


-- Panel 3: Geographic quadrant classification.
--
-- RETAINED FOR COMPLETENESS ONLY. Significance testing (see Q3 header) shows
-- the pattern is indistinguishable from chance. The dashboard uses
-- vw_geo_gender_artefact from 05_dashboard_views.sql as its primary
-- geographic visual, because the real finding is that state-level promo
-- differences track gender mix rather than market behaviour.

DROP VIEW IF EXISTS vw_geo_opportunity CASCADE;

CREATE VIEW vw_geo_opportunity AS
WITH state_stats AS (
    SELECT
        location,
        COUNT(*)                                            AS customers,
        AVG(est_lifetime_rev)                               AS avg_rev,
        AVG(CASE WHEN is_discounted THEN 1.0 ELSE 0 END)    AS promo_rate
    FROM customers
    GROUP BY location
    HAVING COUNT(*) >= (SELECT min_state_n FROM v_params)
)
SELECT
    location,
    customers,
    ROUND(avg_rev, 0)                                                 AS avg_est_rev,
    ROUND(100 * promo_rate, 1)                                        AS promo_rate_pct,
    ROUND(PERCENT_RANK() OVER (ORDER BY avg_rev)::numeric, 2)         AS rev_pctile,
    ROUND(PERCENT_RANK() OVER (ORDER BY promo_rate)::numeric, 2)      AS promo_pctile,
    CASE
        WHEN PERCENT_RANK() OVER (ORDER BY avg_rev) >= 0.5
         AND PERCENT_RANK() OVER (ORDER BY promo_rate) < 0.5
        THEN 'Underlevered' ELSE 'Other'
    END                                                               AS flag
FROM state_stats;


-- Panel 4: Category funnel — entry-point vs. retention categories.
--
-- An earlier version compared each category's MEAN purchase history against
-- the overall MEDIAN, which is not a like-for-like comparison, and labelled
-- all four categories 'Entry-point'. Fixed to compare mean against mean, with
-- a materiality band: a category within 1 purchase of the overall average is
-- reported as Indistinguishable rather than forced into a role.
--
-- Observed result: all four categories return Indistinguishable. Manufacturing
-- a funnel that is not in the data is worse than reporting that the categories
-- do not differ.

DROP VIEW IF EXISTS vw_category_funnel CASCADE;

CREATE VIEW vw_category_funnel AS
WITH benchmark AS (
    SELECT AVG(previous_purchases)                                     AS avg_prev,
           PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY previous_purchases) AS med_prev
    FROM customers
)
SELECT
    c.category,
    COUNT(*)                                                        AS customers,
    ROUND(AVG(c.previous_purchases), 1)                             AS avg_prev_purchases,
    ROUND(AVG(c.previous_purchases) - MAX(b.avg_prev), 2)           AS diff_vs_overall,
    ROUND(100.0 * COUNT(*) FILTER (WHERE c.previous_purchases <= b.med_prev)
                / COUNT(*), 1)                                      AS pct_low_history,
    ROUND(100.0 * COUNT(*) FILTER (WHERE c.previous_purchases >  b.med_prev)
                / COUNT(*), 1)                                      AS pct_high_history,
    ROUND(AVG(c.purchase_amount), 2)                                AS avg_basket,
    ROUND(100.0 * COUNT(*) FILTER (WHERE c.is_discounted)
                / COUNT(*), 1)                                      AS discount_rate,
    CASE
        WHEN AVG(c.previous_purchases) - MAX(b.avg_prev) < -1 THEN 'Entry-point'
        WHEN AVG(c.previous_purchases) - MAX(b.avg_prev) >  1 THEN 'Retention'
        ELSE 'Indistinguishable'
    END                                                             AS funnel_role
FROM customers c
CROSS JOIN benchmark b
GROUP BY c.category;


-- ============================================================================
-- SECTION 5 — SUNSET TARGET SIZING (observed purchase)
-- ----------------------------------------------------------------------------
-- Sizes the recommendation on the single observed purchase per customer.
-- Discount DEPTH is not in the dataset, so this is a sensitivity range around
-- a stated assumption, never a single number. Presenting one figure would be
-- inventing precision that does not exist.
--
-- Note the filter: AND is_discounted. The Subsidised Volume segment contains
-- 935 customers but only 682 are male and only 500 were discounted. You cannot
-- stop discounting customers who receive no discounts, so the 253 women in
-- this segment need an engagement intervention, not a pricing one.
-- ============================================================================

WITH target AS (
    SELECT *
    FROM customers
    WHERE segment = '2. Subsidised Volume'
      AND is_discounted
),
depths AS (
    SELECT unnest(ARRAY[0.10, 0.15, 0.20, 0.25]) AS depth
)
SELECT
    ROUND(d.depth * 100)                                    AS assumed_depth_pct,
    (SELECT COUNT(*) FROM target)                           AS target_customers,
    ROUND((SELECT SUM(purchase_amount) FROM target), 0)     AS observed_revenue,
    ROUND((SELECT SUM(purchase_amount) FROM target)
          * d.depth / (1 - d.depth), 0)                     AS margin_recovered_optimistic,
    ROUND((SELECT SUM(purchase_amount) FROM target)
          * d.depth / (1 - d.depth) * 0.70, 0)              AS margin_recovered_30pct_churn
FROM depths d
ORDER BY d.depth;


-- ============================================================================
-- SECTION 6 — ANNUALISED SUNSET SIZING
-- ----------------------------------------------------------------------------
-- Section 5 understates the opportunity because it counts one purchase per
-- customer. This version multiplies by annual_rate to express recovery per
-- year, and per customer per year.
--
-- Lead with per_customer_per_year. An absolute total from a 3,900-row sample
-- invites the question "is that all?"; a per-customer figure can be scaled by
-- the reader against their real customer count.
--
-- Caveat for the report: annualising relies on annual_rate, and Phase 1 showed
-- frequency and purchase count do not constrain each other in this dataset
-- (16% of customers have implied tenures above 10 years). Directional
-- estimate, not a forecast.
-- ============================================================================

WITH target AS (
    SELECT purchase_amount, annual_rate
    FROM customers
    WHERE segment = '2. Subsidised Volume' AND is_discounted
),
depths AS (SELECT unnest(ARRAY[0.10, 0.15, 0.20, 0.25]) AS depth)
SELECT
    ROUND(d.depth * 100)                                      AS depth_pct,
    COUNT(*)                                                  AS target_customers,
    ROUND(SUM(t.purchase_amount * t.annual_rate), 0)          AS annualised_revenue,
    ROUND(SUM(t.purchase_amount * t.annual_rate)
          * d.depth / (1 - d.depth), 0)                       AS annual_margin_recovered,
    ROUND(SUM(t.purchase_amount * t.annual_rate)
          * d.depth / (1 - d.depth) * 0.70, 0)                AS net_of_30pct_churn,
    ROUND(SUM(t.purchase_amount * t.annual_rate)
          * d.depth / (1 - d.depth) / COUNT(*), 2)            AS per_customer_per_year
FROM target t
CROSS JOIN depths d
GROUP BY d.depth
ORDER BY d.depth;
