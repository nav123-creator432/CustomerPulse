-- ============================================================================
-- Phase 5 — Dashboard Support Views
--
-- Run AFTER 04_segmentation.sql. These carry findings the original four views
-- predate: the gender artefact, the male-scoped discount rates, and the
-- headline KPI strip.
--
-- Safe to re-run. Nothing here drops the customers table.
-- ============================================================================


-- ----------------------------------------------------------------------------
-- Panel 1 source — value distribution with BOTH discount rates.
--
-- discount_rate_all is misleading on its own: no female customer was ever
-- discounted, so it partly measures gender mix. discount_rate_male is the
-- honest version, scoped to the population the brand actually discounts.
-- The dashboard shows the male column and footnotes why.
-- ----------------------------------------------------------------------------

DROP VIEW IF EXISTS vw_value_tier_promo CASCADE;

CREATE VIEW vw_value_tier_promo AS
SELECT
    value_tier,
    CASE value_tier
        WHEN 'T1 Highest' THEN 1 WHEN 'T2' THEN 2 WHEN 'T3' THEN 3
        WHEN 'T4' THEN 4 ELSE 5 END                                  AS tier_rank,
    COUNT(*)                                                         AS customers,
    ROUND(AVG(est_lifetime_rev), 0)                                  AS avg_est_rev,
    ROUND(100.0 * SUM(est_lifetime_rev)
                / SUM(SUM(est_lifetime_rev)) OVER (), 1)             AS pct_of_revenue,
    ROUND(100.0 * COUNT(*) FILTER (WHERE is_discounted)
                / COUNT(*), 1)                                       AS discount_rate_all,
    ROUND(100.0 * COUNT(*) FILTER (WHERE is_discounted AND gender = 'Male')
                / NULLIF(COUNT(*) FILTER (WHERE gender = 'Male'), 0), 1)
                                                                     AS discount_rate_male,
    COUNT(*) FILTER (WHERE gender = 'Male')                          AS male_customers
FROM customers
GROUP BY value_tier;


-- ----------------------------------------------------------------------------
-- Panel 3 source — the gender artefact.
--
-- Replaces the "underlevered states" map. Permutation testing showed state
-- revenue variation is indistinguishable from chance (p = 0.12) and that
-- male-only promo variation is NARROWER than chance (p = 0.93). What remains
-- is the artefact itself: a state's promo rate tracks its male share.
--
-- Plotted as a scatter, this panel shows leadership why the obvious
-- geographic read is wrong.
-- ----------------------------------------------------------------------------

DROP VIEW IF EXISTS vw_geo_gender_artefact CASCADE;

CREATE VIEW vw_geo_gender_artefact AS
SELECT
    location,
    COUNT(*)                                                          AS customers,
    ROUND(100.0 * COUNT(*) FILTER (WHERE gender = 'Male')
                / COUNT(*), 1)                                        AS male_share_pct,
    ROUND(100.0 * COUNT(*) FILTER (WHERE is_discounted)
                / COUNT(*), 1)                                        AS promo_rate_all,
    ROUND(100.0 * COUNT(*) FILTER (WHERE is_discounted AND gender = 'Male')
                / NULLIF(COUNT(*) FILTER (WHERE gender = 'Male'), 0), 1)
                                                                      AS promo_rate_male,
    ROUND(AVG(est_lifetime_rev), 0)                                   AS avg_est_rev
FROM customers
GROUP BY location
HAVING COUNT(*) >= (SELECT min_state_n FROM v_params);


-- ----------------------------------------------------------------------------
-- KPI strip — the five numbers that sit above the four panels.
-- Single row, wide format, which is what Power BI cards want.
-- ----------------------------------------------------------------------------

DROP VIEW IF EXISTS vw_kpi_headline CASCADE;

CREATE VIEW vw_kpi_headline AS
WITH male AS (
    SELECT value_tier,
           AVG(CASE WHEN is_discounted THEN 1.0 ELSE 0 END) AS rate
    FROM customers WHERE gender = 'Male' GROUP BY value_tier
),
target AS (
    SELECT purchase_amount, annual_rate
    FROM customers
    WHERE segment = '2. Subsidised Volume' AND is_discounted
),
tiers AS (
    SELECT SUM(est_lifetime_rev) FILTER (WHERE value_tier = 'T1 Highest') AS top_rev,
           SUM(est_lifetime_rev)                                          AS all_rev
    FROM customers
)
SELECT
    (SELECT COUNT(*) FROM customers)                                  AS total_customers,
    ROUND(100.0 * (SELECT top_rev FROM tiers)
                / (SELECT all_rev FROM tiers), 1)                     AS pct_rev_top_quintile,
    ROUND(100 * ((SELECT MAX(rate) FROM male)
               - (SELECT MIN(rate) FROM male)), 1)                    AS discount_spread_pts_male,
    (SELECT COUNT(*) FROM target)                                     AS sunset_target_customers,
    ROUND((SELECT SUM(purchase_amount * annual_rate) FROM target)
          * 0.20 / 0.80, 0)                                           AS annual_margin_at_stake,
    ROUND((SELECT SUM(purchase_amount * annual_rate) FROM target)
          * 0.20 / 0.80 / (SELECT COUNT(*) FROM target), 2)           AS margin_per_customer_yr;


-- ----------------------------------------------------------------------------
-- Verification — run these and sanity-check before opening Power BI.
-- ----------------------------------------------------------------------------

SELECT * FROM vw_kpi_headline;
SELECT * FROM vw_value_tier_promo ORDER BY tier_rank;
